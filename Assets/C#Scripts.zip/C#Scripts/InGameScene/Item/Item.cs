using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

abstract public class Item
{
    // 아이템 정보
    public Sprite ItemImage = null;
    public string rank = "C";

    // 전달하고 싶은 Stats
    protected Status itemStats;
    public Status ItemStats => itemStats;

    // 가진 주인
    protected GameObject Owner = null;
    protected Status OwnerStatus = null;

    // component
    protected MovementController movementController = null;
    protected AttackController attackController = null;
    protected Creature creature = null;

    // 스킬 함수들
    protected LockObject<Action<GameObject>>[] skill = new LockObject<Action<GameObject>>[5];
    public LockObject<Action<GameObject>>[] Skill => skill;

    public Item(GameObject owner)
    {
        movementController ??= owner.GetComponent<MovementController>();
        attackController ??= owner.GetComponent<AttackController>();
        creature ??= owner.GetComponent<Creature>();
        Owner ??= owner;
    }

    abstract public void NormalAttack();
    abstract public void AddPassive();
    abstract public void RemovePassive();
}