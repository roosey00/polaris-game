using System.Collections.Generic;
using UnityEditor;

public static class SerializedPropertyExtensions
{
    public static IEnumerable<SerializedProperty> GetVisibleChildren(this SerializedProperty property)
    {
        if (!property.hasVisibleChildren) // �ڽ��� ���� ��� ó��
            yield break;

        var currentProperty = property.Copy();
        var nextSiblingProperty = property.Copy();
        bool hasNext = nextSiblingProperty.NextVisible(false);

        if (!hasNext)
            nextSiblingProperty = null;

        if (currentProperty.NextVisible(true))
        {
            do
            {
                if (SerializedProperty.EqualContents(currentProperty, nextSiblingProperty))
                    break;

                yield return currentProperty.Copy();
            }
            while (currentProperty.NextVisible(false));
        }
    }
}
