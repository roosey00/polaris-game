using System.Reflection;
using UnityEditor;
using UnityEngine;

[CustomEditor(typeof(MonoBehaviour), true)] // ��� MonoBehaviour�� ����
public class ReadOnlyEditor : Editor
{
    public override void OnInspectorGUI()
    {
        var targetType = target.GetType();

        // �ʵ�� ������Ƽ ��� Ž��
        var members = targetType.GetMembers(BindingFlags.Instance | BindingFlags.NonPublic | BindingFlags.Public);

        foreach (var member in members)
        {
            // ReadOnly �Ӽ��� ���� ����� ó��
            var readOnlyAttribute = member.GetCustomAttribute<ReadOnlyAttribute>();
            if (readOnlyAttribute != null)
            {
                if (member is FieldInfo field)
                {
                    var value = field.GetValue(target);
                    EditorGUILayout.LabelField(field.Name, value != null ? value.ToString() : "null");
                }
                else if (member is PropertyInfo property)
                {
                    if (property.CanRead)
                    {
                        var value = property.GetValue(target);
                        EditorGUILayout.LabelField(property.Name, value != null ? value.ToString() : "null");
                    }
                }
            }
        }

        // �⺻ �ν����� UI�� ����
        DrawDefaultInspector();
    }
}