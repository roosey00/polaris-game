using UnityEngine;
using UnityEditor;

public class ReadOnlyAttribute : PropertyAttribute { }

#if UNITY_EDITOR
[CustomPropertyDrawer(typeof(ReadOnlyAttribute))]
public class ReadOnlyDrawer : PropertyDrawer
{
    public override void OnGUI(Rect position, SerializedProperty property, GUIContent label)
    {
        // �⺻ GUI ��Ȱ��ȭ
        GUI.enabled = false;

        Debug.Log($"{property.name} is {property.propertyType} type!");

        if (property.propertyType == SerializedPropertyType.Generic) // ���� Ÿ�� ó��
        {
            if (property.objectReferenceValue == null && property.managedReferenceValue == null)
            {
                EditorGUI.LabelField(position, label.text, "null");
                return;
            }

            // �ڽ� �ʵ常 ǥ�� (null�� �ƴ� ���)
            var children = property.GetVisibleChildren();
            float yOffset = position.y;
            foreach (var child in children)
            {
                var childRect = new Rect(position.x, yOffset, position.width, EditorGUIUtility.singleLineHeight);
                EditorGUI.PropertyField(childRect, child, new GUIContent(child.displayName), true);
                yOffset += EditorGUIUtility.singleLineHeight + EditorGUIUtility.standardVerticalSpacing;
            }
        }
        else
        {
            // �Ϲ� �ʵ��� ��� �⺻ �ʵ� ������
            EditorGUI.PropertyField(position, property, label, true);
        }

        // GUI Ȱ��ȭ ����
        GUI.enabled = true;
    }

    public override float GetPropertyHeight(SerializedProperty property, GUIContent label)
    {
        if (property.propertyType == SerializedPropertyType.Generic)
        {
            // CustomClass�� ���� ���� Ÿ���� ��� �ڽ� �ʵ� ���̸� �ջ�
            float height = EditorGUIUtility.singleLineHeight; // Ŭ���� ��ü �� ����
            foreach (var child in property.GetVisibleChildren())
            {
                height += EditorGUIUtility.singleLineHeight + EditorGUIUtility.standardVerticalSpacing;
            }
            return height;
        }

        return EditorGUI.GetPropertyHeight(property, label, true); // �⺻ �ʵ� ����
    }
}
#endif